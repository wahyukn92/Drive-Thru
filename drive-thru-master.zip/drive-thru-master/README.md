Drive-Thru - This project is no longer actively maintained. 
==========
[![Build Status](https://travis-ci.org/Comcast/drive-thru.svg)](https://travis-ci.org/Comcast/drive-thru)

[http://comcast.github.io/drive-thru/](http://comcast.github.io/drive-thru/)

##Summary
Drive-Thru is a helper utility for making HTTP requests.  It is especially useful when interacting with REST APIs as it simplifies the process of constructing a request and serializing/deserializing data in/from those requests

![Drive-Thru](http://comcast.github.io/drive-thru/images/drive-thru-shield.png)

##How do I use it?
You can find ample documentation in the javadocs for the various apis.   Additionally, please see the `src\test` package for example tests written using drive-thru.

##Submitting Issues
Please file a github issue for any problems or feature requests (or better yet, submit a pull request!)
